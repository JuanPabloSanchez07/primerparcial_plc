def nombre():
  print("Dame tu nombre, porfi")
  x = input()
  print("Tu nombre es",x)

nombre()