def calculadora_descuento_comida_rapida():
    precio_original = float(input("Ingresa el precio original de la comida: "))
    descuento_porcentaje = float(input("Ingresa el porcentaje de descuento: "))

    descuento = precio_original * (descuento_porcentaje / 100)
    precio_final = precio_original - descuento

    print(f"El precio final después del descuento es de ${precio_final:.2f}, con un ahorro de ${descuento:.2f}.")

calculadora_descuento_comida_rapida()