# Función para convertir de Celsius a Fahrenheit
def celsius_a_fahrenheit(celsius):
    fahrenheit = (celsius * 9/5) + 32
    return fahrenheit

# Función para convertir de Celsius a Kelvin
def celsius_a_kelvin(celsius):
    kelvin = celsius + 273.15
    return kelvin

# Función principal
def main():
    try:
        celsius = float(input("Ingresa la temperatura en grados Celsius: "))
        fahrenheit = celsius_a_fahrenheit(celsius)
        kelvin = celsius_a_kelvin(celsius)

        print(f"{celsius} grados Celsius equivalen a {fahrenheit} grados Fahrenheit")
        print(f"{celsius} grados Celsius equivalen a {kelvin} Kelvin")

    except ValueError:
        print("Por favor, ingresa una temperatura válida en grados Celsius.")

if __name__ == "__main__":
    main()