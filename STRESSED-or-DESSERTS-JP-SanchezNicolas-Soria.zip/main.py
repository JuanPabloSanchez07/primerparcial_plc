def invertir_palabra(palabra):
    palabra_invertida = palabra[::-1]  # Invertir la palabra usando slicing
    return palabra_invertida

# Solicitar al usuario que ingrese una palabra
palabra_original = input("Ingresa una palabra: ")
palabra_invertida = invertir_palabra(palabra_original)
print("Palabra original:", palabra_original)
print("Palabra invertida:", palabra_invertida)
