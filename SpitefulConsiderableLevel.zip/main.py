# Solicitar al usuario la cantidad de dinero invertida, la tasa de interés anual y el número de años
cantidad_invertida = float(input("Ingrese la cantidad de dinero invertida: "))
tasa_interes_anual = float(input("Ingrese la tasa de interés anual (en porcentaje): "))
num_anios = int(input("Ingrese el número de años: "))
# Convertir la tasa de interés de porcentaje a decimal
tasa_interes_decimal = tasa_interes_anual / 100
# Calcular el interés ganado
interes_ganado = cantidad_invertida * tasa_interes_decimal * num_anios
# Calcular el monto total después de la inversión
monto_total = cantidad_invertida + interes_ganado
# Mostrar el resultado
print(f"Interés ganado: {interes_ganado:.2f} dólares")
print(f"Monto total después de la inversión: {monto_total:.2f} dólares")