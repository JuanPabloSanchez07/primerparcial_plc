# Solicitar al usuario el costo de la comida y el porcentaje de propina
costo_comida = float(input("Ingrese el costo de la comida: $"))
porcentaje_propina = float(input("Ingrese el porcentaje de propina que desea dar (por ejemplo, 15 para el 15%): "))

# Calcular la cantidad de propina y el monto total a pagar
propina = costo_comida * (porcentaje_propina / 100)
total_a_pagar = costo_comida + propina

# Mostrar los resultados
print(f"Costo de la comida: ${costo_comida:.2f}")
print(f"Porcentaje de propina: {porcentaje_propina}%")
print(f"Cantidad de propina: ${propina:.2f}")
print(f"Monto total a pagar: ${total_a_pagar:.2f}")