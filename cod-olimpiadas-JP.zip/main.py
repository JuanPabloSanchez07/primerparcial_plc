def suma (a,b):
x=a+b
return x

def resta (a,b):
  x = a - b

print("Dame el primer número:")
a = int(input())
print("Dame el segundo número:")
b = int(input())
print("la suma da",suma(a,b), "y la resta da",resta(a,b))